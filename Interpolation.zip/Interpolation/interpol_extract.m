clc; clear;

% Read and validate grayscale images
[filename, pathname] = uigetfile('*.png', 'Select Original Cover (PNG) image');
oi=load_grayscale_image(filename, pathname);

[filename, pathname] = uigetfile('*.png', 'Select Stego (PNG) image');
final_expanded=load_grayscale_image(filename, pathname);

    % 32-byte random data
    bytes = uint8([
        72, 203, 5, 199, 134, 51, 240, 117, ...
        9, 186, 248, 66, 111, 13, 92, 33, ...
        201, 187, 158, 47, 126, 89, 144, 213, ...
        44, 132, 176, 255, 31, 61, 8, 103
    ]);
    
    required_bits = numel(final_expanded);
    stegokey = generate_stegokey(bytes, required_bits);
    num_ones = sum(stegokey(:));
    
    % Define three different seeds (can be any distinct values) 
    seed1 = uint8([11 12 13 14 15 16 17 18 19 20]);  
    seed2 = uint8([21 22 23 24 25 26 27 28 29 30]);  
    
    % Generate stego keys for each matrix
    stegokey1 = generate_stegokey(seed1, required_bits)+1;% m*n)+1; 
    stegokey2 = generate_stegokey(seed2, required_bits)+1; %m*n)+1;
    [m, n] = size(final_expanded);
    coverimage = final_expanded(1:2:end, 1:2:end);
    % coverimage = zeros(m/2, n/2);
    
    %---------------- Reconstructing the Original Cover -----------------------
    r = 0;
    c = 1;
    k = 1;
    
    for i = 1:m
        if mod(i, 2) > 0
            r = r + 1;
        end
        c = 1; % Reset column index at the start of each row
        for j = 1:2:n
            if mod(i, 2) > 0
                if stegokey1(k) == 1
                    coverimage(r, c) = final_expanded(i, j+1);
                else
                    coverimage(r, c) = final_expanded(i, j);
                end
                c = c + 1;
            end
            k = k + 1;
        end
    end

% Ensure images are grayscale and same size
    if size(oi,3) ~= 1 || size(coverimage,3) ~= 1
        error('Images must be grayscale (2D).');
    end
    if ~isequal(size(oi), size(coverimage))
        error('Images must be the same size.');
    end
    % Compute pixel-by-pixel difference
diff_pixels = oi ~= coverimage;

% Count differing pixels
num_differences = sum(diff_pixels(:));
diff_message = ['Number of differing pixels: ', num2str(num_differences)];
% disp(diff_message);

% Visualize differences
diff_highlight = zeros(size(oi), 'uint8');
diff_highlight(diff_pixels) = 255; % highlight differences in white

% Create figure
hFig = figure('Name', 'Comparison', 'NumberTitle', 'off');

% Plot images
subplot(1,3,1);
imshow(oi, []);
title('CoverImage');

subplot(1,3,2);
imshow(coverimage, []);
title('Recovered');

subplot(1,3,3);
imshow(diff_highlight);
title('Differences Highlighted');

% Adjust figure size to make space for text
set(hFig, 'Position', [100, 100, 1000, 400]);  % Optional: resize window

% Add text message below the images
uicontrol('Style', 'text', ...
          'Parent', hFig, ...
          'String', diff_message, ...
          'Units', 'normalized', ...
          'Position', [0.35 0.02 0.3 0.04], ...  % Adjust as needed
          'FontSize', 11, ...
          'BackgroundColor', get(hFig, 'Color'));
    
    % % % % Prompt the user with a dialog box to save the figure
    % % % choice = questdlg('Do you want to save the Extracted Image (PNG) file?', ...
    % % %     'Save Figure', ...
    % % %     'Yes', 'No', 'No');
    % % % 
    % % % if strcmp(choice, 'Yes')
    % % %     % Open a save dialog for PNG files
    % % %     [file, path] = uiputfile('*.png', 'Save as PNG', 'Dr.Khan.Farhan.Rafat.png');
    % % %     if isequal(file, 0) || isequal(path, 0)
    % % %         disp('User canceled the save operation.');
    % % %     else
    % % %         % Save the figure as PNG
    % % %         imwrite(coverimage, fullfile(path, file));
    % % %         % % saveas(hFig, fullfile(path, file));
    % % %         disp(['Figure saved as ', fullfile(path, file)]);
    % % %     end
    % % % else
    % % %     disp('Figure not saved.');
    % % %     return;
    % % % end
    
    % Close the figure
    close(hFig);
    
    mxl=160; % Header Length
    idx=1;
    imx=1;
    tm=[];

    for i = 1:m
        for j = 1:2:n
            if imx > mxl % extracted header bits
                break;
            end
    
            switch stegokey(idx)
                case 0 %Insert dummy data
                       % ---( No Action )---
                case 1 % Extract message bits
                    switch stegokey1(idx)
                        case 1  %select first pixel
                                switch stegokey2(idx)
                                    case 1  
                                            tm=[tm, bitget(final_expanded(i,j), 1)];
                                            imx=imx+1; 
                                    case 2  
                                            tm=[tm, bitget(final_expanded(i,j), 1)];
                                            tm=[tm, bitget(final_expanded(i,j), 2)];
                                            imx=imx+2;
                                end
                        case 2  %select second pixel
                                switch stegokey2(idx)
                                    case 1  
                                            tm=[tm, bitget(final_expanded(i,j+1), 1)];
                                            imx=imx+1;
                                    case 2  
                                            tm=[tm, bitget(final_expanded(i,j+1), 1)];
                                            tm=[tm, bitget(final_expanded(i,j+1), 2)];
                                            imx=imx+2;
                                end
                    end
            end
                idx=idx+1;
        end
            if imx > mxl 
                % disp(imx);
                break;
            end
    end
    binary_str_tm = char(tm + '0');
    num_bits = length(tm);
    num_bytes = floor(num_bits / 8);
    bits_reshaped = reshape(tm(1:num_bytes*8), 8, [])';  % Reshape into Nx8
    msg_bytes = bi2de(bits_reshaped, 'left-msb');  % Convert bits to decimal bytes
    original_text = char(msg_bytes)'; % Header retrieved
    
    ul=str2double(original_text(1:8)); % Extracted Hidden Message length in Bytes
    fx=original_text(9:20); % Extract File name 
    
    mxl=(20+ul)*8; % Header Length
    idx=1;
    imx=1;
    tm=[];
    
    
    for i = 1:m
        for j = 1:2:n
            if imx > mxl % extracted header bits
                break;
            end
    
            switch stegokey(idx)
                case 1% Extract message bits
                    switch stegokey1(idx)
                        case 1  %select first pixel
                                switch stegokey2(idx)
                                    case 1  % Change LSB ONLY
                                            tm=[tm, bitget(final_expanded(i,j), 1)];
                                            imx=imx+1; 
                                    case 2  % Change 2-LSBs
                                            tm=[tm, bitget(final_expanded(i,j), 1)];
                                            tm=[tm, bitget(final_expanded(i,j), 2)];
                                            imx=imx+2;
                                end
                        case 2  %select second pixel
                                switch stegokey2(idx)
                                    case 1  % Change LSB ONLY
                                            tm=[tm, bitget(final_expanded(i,j+1), 1)];
                                            imx=imx+1;
                                    case 2  % Change 2-LSBs
                                            tm=[tm, bitget(final_expanded(i,j+1), 1)];
                                            tm=[tm, bitget(final_expanded(i,j+1), 2)];
                                            imx=imx+2;
                                end
                    end
            end
                idx=idx+1;
        end
            if imx > mxl %Length exceeds message length
                % disp(imx);
                break;
            end
    end
    
    binary_str_tm = char(tm + '0');
    num_bits = length(tm);
    num_bytes = floor(num_bits / 8);
    bits_reshaped = reshape(tm(1:num_bytes*8), 8, [])';  % Reshape into Nx8
    msg_bytes = bi2de(bits_reshaped, 'left-msb');  % Convert bits to decimal bytes
    original_text = char(msg_bytes)'; % Hidden Message
    original_text = original_text(21:end);
    
    % Open file for writing in binary mode
    fileID = fopen(fx, 'w');
    
    % Check if file opened successfully
    if fileID == -1
        error('Cannot open file for writing.');
    end
    
    % Write bytes to the file
    fwrite(fileID, original_text, 'uint8');
    
    % Close the file
    fclose(fileID);
    
    winopen(fx);
    
    
    
    disp('🧠 Dr.Khan Farhan Rafat © 2025: Embedding ended here!')
% end
%==========================================================================
function stegokey = generate_stegokey(seed, required_bits)
    % Generate a binary stegokey using iterative SHA-256 hashing with MSB removed
    import java.security.*;

    hash = MessageDigest.getInstance('SHA-256');
    stegokey_bits = [];

    while numel(stegokey_bits) < required_bits
        hash.update(seed);
        digest = uint8(hash.digest());

        digest = bitand(digest, 127);

        % Convert remaining 7 bits of each byte to binary
        bits = reshape(de2bi(digest, 7, 'left-msb')', 1, []); % 7 bits per byte
        stegokey_bits = [stegokey_bits, bits];

        seed = digest;  % Feedback loop
    end

    stegokey = stegokey_bits(1:required_bits); % Trim to desired length
end

function oim = load_grayscale_image(filename, pathname)

    if isequal(filename, 0)
        error('User canceled the file selection.');
    end

    fullFilePath = fullfile(pathname, filename);
    oim = imread(fullFilePath);

    % Validation checks
    if size(oim, 3) ~= 1
        error('Only single-channel grayscale images are supported.');
    end

    if ~isa(oim, 'uint8')
        error('Only 8-bit grayscale images are supported.');
    end

    % fprintf('✅ Loaded image: %s (Size: %dx%d)\n', filename, size(oim,1), size(oim,2));
end




% % % % Specify the folder containing grayscale PNG images
% % % folder_path = 'C:\oi';
% % % 
% % % % Get list of all PNG files in the folder
% % % image_files = dir(fullfile(folder_path, '*.png'));
% % % 
% % % % Check if images are found
% % % if isempty(image_files)
% % %     error('No PNG images found in the specified folder.');
% % % end
% % % 
% % % % Loop through each image file
% % % for k = 1:length(image_files)
% % %         % Full file path
% % %         image_path = fullfile(folder_path, image_files(k).name);
% % % 
% % %         % Read the image
% % %         oi = imread(image_path);
% % % 
% % %         % Ensure it's a single-channel grayscale image
% % %         if size(oi, 3) ~= 1
% % %             warning('Image %s is not grayscale. Skipping.', image_files(k).name);
% % %             continue;
% % %         end
% % % 
% % %         % Display information
% % %         fprintf('Loaded grayscale image: %s (Size: %dx%d)\n', ...
% % %             image_files(k).name, size(oi,1), size(oi,2));
% % % 
% % % end
