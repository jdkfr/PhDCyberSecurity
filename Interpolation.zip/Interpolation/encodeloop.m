clc;clear;

folder_path = 'C:\oi';
image_files = dir(fullfile(folder_path, '*.png'));
if isempty(image_files)
    error('No PNG images found in the specified folder.');
end
for k = 1:length(image_files)
        image_path = fullfile(folder_path, image_files(k).name);
        oi = imread(image_path);
        if size(oi, 3) ~= 1
            warning('Image %s is not grayscale. Skipping.', image_files(k).name);
            return;
        end
        fprintf('Loaded grayscale image: %s (Size: %dx%d)\n', ...
            image_files(k).name, size(oi,1), size(oi,2));

        [m, n] = size(oi);
        expanded_cols = zeros(m, 2*n, class(oi));
        for j = 1:n
            col_idx = 2*j - 1;
            expanded_cols(:, col_idx) = oi(:, j);
            expanded_cols(:, col_idx + 1) = oi(:, j);
        end
        
        final_expanded = zeros(2*m, 2*n, class(oi));
        for i = 1:m
            row_idx = 2*i - 1;
            final_expanded(row_idx, :) = expanded_cols(i, :);
            final_expanded(row_idx + 1, :) = expanded_cols(i, :);
        end

        bytes = uint8([
            72, 203, 5, 199, 134, 51, 240, 117, ...
            9, 186, 248, 66, 111, 13, 92, 33, ...
            201, 187, 158, 47, 126, 89, 144, 213, ...
            44, 132, 176, 255, 31, 61, 8, 103
        ]);
        
        required_bits = numel(final_expanded);
        stegokey = generate_stegokey(bytes, required_bits);
        num_ones = sum(stegokey(:));
        rng(4294967295);

        filename='C:\Users\user\Documents\pakistan.txt';
        fid = fopen(filename, 'rb');
        if fid == -1
            error('Failed to open the file. Check the path and permissions.');
        end
        msg_bytes = fread(fid, inf, 'uint8');
        fclose(fid);

        [fp, fname, ext]=fileparts(filename);
        if length(fname) > 5
            fname = strtrim(fname(1:5));
        end
        fname = [fname, 'kfr']; % Added suffix
        
        % ✅ Correct: use length, not strlength
            header = sprintf('%8.8d%8.8s%-4.4s%s', numel(msg_bytes), fname, ext, msg_bytes);
            header_bin = dec2bin(header,8);
            header_bin = reshape(header_bin.', 1, []); % header_bin(1:160)

            if num_ones<numel(header_bin)
                disp(num_ones)
                disp(numel(header_bin))
                error("Message exceeds embedding capacity!.")
            end

            % Define three different seeds (can be any distinct values) 
            seed1 = uint8([11 12 13 14 15 16 17 18 19 20]);  
            seed2 = uint8([21 22 23 24 25 26 27 28 29 30]);  
            
            % Generate stego keys for each matrix
            stegokey1 = generate_stegokey(seed1, required_bits)+1;
            stegokey2 = generate_stegokey(seed2, required_bits)+1;

            [m, n] = size(final_expanded);
            mxl=numel(header_bin);
            idx=1;
            imx=1;

            stegimage=final_expanded;

    for i=1:m
        for j=1:2:n
            if imx>mxl
                break;
            end
            switch stegokey(idx)
                case 0 % Dummy bits
                    switch stegokey1(idx)
                        case 1 %1st pixel
                            switch stegokey2(idx)
                                case 1 % 1-bit
                                    stegimage(i, j)=bitset(stegimage(i, j),1,randi([0, 1]));
                                case 2 % 2-bits
                                    stegimage(i, j)=bitset(stegimage(i, j),1,randi([0, 1]));
                                    stegimage(i, j)=bitset(stegimage(i, j),2,randi([0, 1]));
                            end
                        case 2 %2nd pixel
                            switch stegokey2(idx)
                                case 1 % 1-bit
                                    stegimage(i, j+1)=bitset(stegimage(i, j+1),1,randi([0, 1]));
                                case 2 %2-bits
                                    stegimage(i, j+1)=bitset(stegimage(i, j+1),1,randi([0, 1]));
                                    stegimage(i, j+1)=bitset(stegimage(i, j+1),2,randi([0, 1]));
                            end
                    end
                case 1 % Message bits
                    switch stegokey1(idx)
                        case 1 %1st pixel
                            switch stegokey2(idx)
                                case 1 % 1-bit
                                    stegimage(i, j)=bitset(stegimage(i, j),1,str2double(header_bin(imx)));
                                    imx=imx+1;
                                case 2 % 2-bits
                                    stegimage(i, j)=bitset(stegimage(i, j),1,str2double(header_bin(imx)));
                                    imx=imx+1;
                                    if imx>mxl
                                        break;
                                    else
                                        stegimage(i, j)=bitset(stegimage(i, j),2,str2double(header_bin(imx)));
                                        imx=imx+1;
                                    end
                            end
                        case 2 %2nd pixel
                            switch stegokey2(idx)
                                case 1 % 1-bit
                                    stegimage(i, j+1)=bitset(stegimage(i, j+1),1,str2double(header_bin(imx)));
                                    imx=imx+1;
                                case 2 %2-bits
                                    stegimage(i, j+1)=bitset(stegimage(i, j+1),1,str2double(header_bin(imx)));
                                    imx=imx+1;
                                    if imx>mxl
                                        break;
                                    else
                                        stegimage(i, j+1)=bitset(stegimage(i, j+1),2,str2double(header_bin(imx)));
                                        imx=imx+1;
                                    end
                            end
                    end
            end
            idx=idx+1;
        end
    end

for i1=i:m
    for j1=j:2:n
        switch stegokey(idx)
            case {0, 1}
            switch stegokey1(idx)
                case 1
                    switch stegokey2(idx)
                        case 1
                            stegimage(i1, j1)=bitset(stegimage(i1, j1),1,randi([0, 1]));
                        case 2
                            stegimage(i1, j1)=bitset(stegimage(i1, j1),1,randi([0, 1]));
                            stegimage(i1, j1)=bitset(stegimage(i1, j1),2,randi([0, 1]));
                    end
                case 2
                    switch stegokey2(idx)
                        case 1
                            stegimage(i1, j1+1)=bitset(stegimage(i1, j1+1),1,randi([0, 1]));
                        case 2
                            stegimage(i1, j1+1)=bitset(stegimage(i1, j1+1),1,randi([0, 1]));
                            stegimage(i1, j1+1)=bitset(stegimage(i1, j1+1),2,randi([0, 1]));
                    end

            end
        end
        idx=idx+1;
    end
end

    fullFileName = strcat("c:\si\kfr_",image_files(k).name);
    imwrite(stegimage, fullFileName);
    fprintf('Image saved to: %s\n', fullFileName);

evaluate_stego_quality(final_expanded, stegimage, stegokey)

end

function evaluate_stego_quality(original_img, stego_img, stegokey)
% EVALUATE_STEGO_QUALITY - Evaluates and compares original and stego images.
%
% Inputs:
%   original_img - Original interpolated grayscale image (matrix).
%   stego_img    - Stego image after embedding (matrix).
%   stegokey     - Matrix (same size as image) with values 1 or 2
%                  indicating how many bits were embedded per pixel.
%
% Computes and displays:
%   - Mean
%   - Standard Deviation
%   - PSNR
%   - Pearson Correlation
%   - SSIM
%   - MS-SSIM
%   - Entropy
%   - Bits per Pixel
%   - Bit Embedding Capacity (bits and bpp)

fprintf('\n📊 === Stego Quality Evaluation Report ===\n');

% Convert to double for precision
original = double(original_img);
stego = double(stego_img);

% 1. Mean and Standard Deviation
mean_orig = mean(original(:));
mean_stego = mean(stego(:));
std_orig = std(original(:));
std_stego = std(stego(:));

% 2. PSNR
psnr_val = psnr(uint8(stego), uint8(original));

% 3. Pearson Correlation Coefficient
corr_val = corr2(original, stego);

% 4. SSIM
[ssim_val, ~] = ssim(uint8(stego), uint8(original));

% 5. MS-SSIM (Multiscale SSIM)
if exist('multissim', 'file')
    [msssim_val, ~] = multissim(uint8(stego), uint8(original));
else
    warning('MS-SSIM not available. Install Image Processing Toolbox or define multissim().');
    msssim_val = NaN;
end

% 6. Entropy
entropy_orig = entropy(uint8(original));
entropy_stego = entropy(uint8(stego));

% 7. Bits per Pixel (assuming 8-bit grayscale image)
bpp = 8;

% 8. Bit Embedding Capacity
total_embedded_bits = sum(stegokey(:));  % From stegokey (1 or 2 bits per pixel)
total_pixels = numel(original_img);
embedding_capacity_bpp = total_embedded_bits / total_pixels;

% Display Report
fprintf('\n📈 Statistical Metrics:\n');
fprintf('---------------------------------------------------\n');
fprintf('Metric                  | Original   | Stego\n');
fprintf('------------------------|------------|------------\n');
fprintf('Mean                    | %10.4f | %10.4f\n', mean_orig, mean_stego);
fprintf('Std Deviation           | %10.4f | %10.4f\n', std_orig, std_stego);
fprintf('Entropy                 | %10.4f | %10.4f\n', entropy_orig, entropy_stego);
fprintf('Bits per Pixel (bpp)    | %10d | %10d\n', bpp, bpp);
fprintf('------------------------|------------|------------\n');

fprintf('\n💾 Embedding Capacity:\n');
fprintf('---------------------------------------------------\n');
fprintf('Total Embedded Bits     : %d bits\n', total_embedded_bits);
fprintf('Embedding Capacity (bpp): %.4f\n', embedding_capacity_bpp);
fprintf('---------------------------------------------------\n');

fprintf('\n✅ Perceptual Quality Metrics:\n');
fprintf('---------------------------------------------------\n');
fprintf('PSNR                    : %.4f dB\n', psnr_val);
fprintf('Pearson Correlation     : %.4f\n', corr_val);
fprintf('SSIM                    : %.4f\n', ssim_val);
fprintf('MS-SSIM                 : %.4f\n', msssim_val);
fprintf('---------------------------------------------------\n\n');

end


function stegokey = generate_stegokey(seed, required_bits)
    % Generate a binary stegokey using iterative SHA-256 hashing with MSB removed
    import java.security.*;

    hash = MessageDigest.getInstance('SHA-256');
    stegokey_bits = [];

    while numel(stegokey_bits) < required_bits
        hash.update(seed);
        digest = uint8(hash.digest());

        digest = bitand(digest, 127);

        bits = reshape(de2bi(digest, 7, 'left-msb')', 1, []);
        stegokey_bits = [stegokey_bits, bits];

        seed = digest; 
    end

    stegokey = stegokey_bits(1:required_bits);
end
