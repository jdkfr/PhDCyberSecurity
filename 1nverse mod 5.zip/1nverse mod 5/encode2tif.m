clc;
%
%               2-channel RDH Image Steganography
%                     by: KHAN FARHAN RAFAT
%                        INVERSE Mod 5
% folderPath = 'C:\oi'; %ORIGINAL IMAGES
folderPath = 'C:\Users\user\Downloads\Set12'; %ORIGINAL IMAGES
messageFile = 'C:\Users\user\Downloads\lsbMatching.txt';
stegoKey = 'C:\Users\user\Documents\2019-keyz.txt';
stegoImage = 'c:\set12ix\inv5';
% stegoImage = 'c:\ICACS20252channel\';
% rng('shuffle');
fileList = dir(fullfile(folderPath, '*.png'));
for ifile = 1:length(fileList)
    [~, fileName, ex] = fileparts(fileList(ifile).name); % Extract name without extension
    newFileName = strcat(strcat(fileName, '_KFR'),'.TIF'); % Append "_KFR" to the name
    filenameWithExtension=strcat(strcat(stegoImage,'\'),newFileName);
    disp(newFileName); % Display the new file name

    option = 0;

    coverImage = strcat(strcat(fileList(ifile).folder,"\"), fileList(ifile).name); %'C:\Set12e\10.png';
    originalImage = uint8(imread(coverImage));
    [rows, cols, cx]=size(originalImage);
    if cx ~= 1
        error('The input image must be a single-channel (grayscale) image.');
    end
    oImageLength=rows * cols;
    
    % Read the message file as binary
    fileID = fopen(messageFile, 'rb');  % Open in binary read mode
    if fileID == -1
        error('Unable to open the message file: %s', messageFile);
    end
    fileContent = fread(fileID, Inf, '*uint8');  % Read entire file as uint8 (binary)
    fclose(fileID);  % Close the file
    %--------( MESSAGE LENGTH)-----------------
    msgl=numel(fileContent);
    
    % Get the file name and extension
    [~, name, ext] = fileparts(messageFile);
    name=strip(name);
    ext=strip(ext);
    
    % Validate and truncate name and extension
    maxNameLength = 8;  % Maximum allowed length for the file name
    maxExtLength = 4;   % Maximum allowed length for the file extension
    if isempty(name) || isempty(ext)
        error('Invalid file name or extension in the provided file path.');
    end
    if length(name) > maxNameLength
        name = name(1:maxNameLength);  % Truncate to the first 8 characters
    end
    if length(ext) > maxExtLength
        ext = ext(1:maxExtLength);  % Truncate to the first 4 characters
    end
    
    if oImageLength < numel(fileContent)
        error('Choose a Larger Image');
    end
    
    % Read the stegokey file and compute the hash
    fileID = fopen(stegoKey, 'rb');  % Open in binary read mode
    if fileID == -1
        error('Unable to open the stegokey file: %s', stegoKey);
    end
    byteData = fread(fileID, Inf, '*uint8');  % Read stegokey as bytes
    fclose(fileID);
    % Close the file
    
    hash = uint8(System.Security.Cryptography.SHA256Managed().ComputeHash(byteData));
    
    hashBin = reshape(dec2bin(hash, 8).', 1, []);

    padByte=oImageLength - msgl*8;
    if padByte<0
        error("Message Exceeds Cover Image Pixels.")
    end
    message = sprintf('%08d%8.8s%4.4s%s', double(msgl), name, ext, fileContent);
    messageBin = reshape(dec2bin(message, 8).', 1, []);
    messageBinLength = numel(messageBin);
    % % % messageBin(1:20) % Message Bits

    byteData=hash;
    hash2 = [];
    num_ones=0;
     x1=1;
     x2=0;
     while(x1<3)
            bitstream='';
            num_ones=0;
            hash2='';
        while (1)
            hash1 = uint8(System.Security.Cryptography.SHA256Managed().ComputeHash(byteData));
            g=flip(hash1);
            hash2 = [hash2 hash1];
            byteData = g;
            bitstream = [bitstream reshape(dec2bin(hash2, 8).', 1, [])];
            num_ones = num_ones + sum(bitstream == '1');
            if num_ones >= oImageLength && numel(bitstream) >= oImageLength
                break;
            end
        end
        if x1==1
            hp1=bitstream;
            byteData=g;
            x1=2;
        elseif x1==2
            hp2=bitstream;
            x1=3;
        else
            error("HASH Error.")
        end
     end


rng(sum(hash));
imageSize = oImageLength;
onesPercentage = 0.60; % Percentage of '1's in the stegokey (85%)

% Step 1: Calculate the number of '1's and '0's needed
numOnes = round(imageSize * onesPercentage); % Number of '1's (85% of imageSize)
numZeros = imageSize - numOnes; % Remaining positions filled with '0's

% Step 2: Randomly extract '1's from 'hp1' equal to 'numOnes' or available
onesIndices = find(hp1 == '1'); % Find indices of '1's in hp1
selectedIndices = randsample(onesIndices, min(numOnes, length(onesIndices))); % Select indices
selectedBits = hp1(selectedIndices); % Extract the '1's

% Step 3: Create an empty stegokey of size 'imageSize'
stegokey = repmat(' ', 1, imageSize);

% Step 4: Randomly place the selected '1's into stegokey
if ~isempty(selectedBits)
    randomPositions = randperm(imageSize, length(selectedBits)); % Generate random positions
    stegokey(randomPositions) = '1'; % Place selected '1's in stegokey
    numOnes = numOnes - length(selectedBits); % Adjust remaining '1's to place
end

% Step 5: Randomly place remaining '1's and all '0's
emptyPositions = find(stegokey == ' '); % Find empty positions
remainingBits = [ones(1, numOnes), zeros(1, numZeros)]; % Create bits for remaining positions
remainingBits = remainingBits(randperm(length(remainingBits))); % Shuffle remaining bits randomly
stegokey(emptyPositions) = char(remainingBits + '0'); % Fill empty positions

% Step 6: Convert stegokey to a binary string
hp1 = char(stegokey); % Ensure it's a character array

% Output
% disp('Generated Stegokey:');
% disp(hp1);
%

    cporiginalImage=originalImage;

% fprintf("%20s\n",hp1);
% fprintf("%20s\n",hp2);
% fprintf("%d\n",numel(hp1));
% fprintf("%d\n",numel(hp2));

per=mod(sum(hash),2)+1;
%==========================================================================
% Ensure messageBin is a binary vector
if ischar(messageBin)
    messageBin = messageBin - '0'; % Convert character array to numeric binary
end

k=0;
q=0;
chp1=0;
chp2=0;
counter = 0;
modf=rows *cols;

for i = 1:rows
    for j = 1:cols
        k=k+1;
        if hp1(k)=='1'
            if counter >= messageBinLength
                % i=rows+1;
                break;
            end
            counter = mod(counter, modf) + 1; % message bit selection
            xy=bitget(originalImage(i, j), 1);
            xr = messageBin(counter); % XoR
            if xy==1 
                if xr==0
                    xr=1;
                else
                    xr=0;
                end
            end
            yz=bitxor(hp2(counter)-'0', xr);
            cporiginalImage(i, j)=bitset(cporiginalImage(i, j), 1, yz);
        else
            cporiginalImage(i, j)=bitset(cporiginalImage(i, j), 1, randi([0, 1]));
        end
    end
end


% % Step 1: Extract the filename (without the extension)
% [~, filename, ~] = fileparts(coverImage);
% 
% % Step 2: Append the '.tif' extension
% filenameWithExtension = strcat('c:\set12x\',strcat(filename, '.tif'));

if per==1
   % Write the first page (red channel)
    imwrite(originalImage, filenameWithExtension, 'WriteMode', 'overwrite');
    
    % Write the second page (green channel)
    imwrite(cporiginalImage, filenameWithExtension, 'WriteMode', 'append');
else
   % Write the first page (red channel)
    imwrite(cporiginalImage, filenameWithExtension, 'WriteMode', 'overwrite');
    
    % Write the second page (green channel)
    imwrite(originalImage, filenameWithExtension, 'WriteMode', 'append');
end

% Compute MSE, PSNR, and SSIM
mseValue = immse(cporiginalImage, originalImage);
psnrValue = psnr(cporiginalImage, originalImage);
[ssimValue, ~] = ssim(cporiginalImage, originalImage);

% Create a modal figure and center it on the screen
screenSize = get(0, 'ScreenSize');
figWidth = 800; % Figure width
figHeight = 400; % Figure height
figPosition = [ ...
    (screenSize(3) - figWidth) / 2, ... % Center horizontally
    (screenSize(4) - figHeight) / 2, ... % Center vertically
    figWidth, ...
    figHeight ...
];
hFig = figure('Name', 'Farhan''s Modulo 5 Steganography', ...
              'NumberTitle', 'off', ...
              'MenuBar', 'none', ...
              'ToolBar', 'none', ...
              'WindowStyle', 'normal', ...
              'Position', figPosition);

% Display the original image on the left
subplot(1, 2, 1);
imshow(originalImage);
title('Original Image', 'FontSize', 12, 'FontWeight', 'bold');

% Display the modified image on the right
subplot(1, 2, 2);
imshow(cporiginalImage);
title('Stego Image', 'FontSize', 12, 'FontWeight', 'bold');

% Move annotation 2 inches down
originalDim = [0.55, 0.05, 0.4, 0.2]; % Original position
pixelsPerInch = 96;
screenHeightPixels = screenSize(4); % Screen height in pixels
normalizedOffset = (2 * pixelsPerInch) / screenHeightPixels; % Convert 2 inches to normalized units
newY = originalDim(2) - normalizedOffset; % Adjust y-position

% Ensure newY does not drop below 0
newY = max(newY, 0); % Ensure the annotation stays within the figure

% Update the annotation position
metricsString = sprintf( ...
    'Stego Image Quality Assessment:\nMSE: %.4f\nPSNR: %.4f dB\nSSIM: %.4f', ...
    mseValue, psnrValue, ssimValue ...
);
dim = [originalDim(1), newY, originalDim(3), originalDim(4)];
annotation('textbox', dim, 'String', metricsString, ...
           'EdgeColor', 'none', ...
           'HorizontalAlignment', 'left', ...
           'FontSize', 10, ...
           'FontWeight', 'bold');

end
% Why Is The Above Important?

% Spreading the Embedding: The second loop ensures that the message bits 
% are embedded over the entire expanded image, and the random bits serve 
% to mask the changes in the image. Without this, the embedded message 
% could leave detectable patterns if certain parts of the image are left 
% unchanged or filled with predictable bits.

% Randomization for Security: By embedding random bits in places where the 
% message isn't embedded, the steganography becomes harder to detect. 
% The random bits prevent attackers from easily discerning which parts of 
% the image contain the hidden message and which parts are left untouched.

% Conclusion:
% Padding is not redundant. Instead, it serves a valuable purpose 
% of filling the image with random bits after the message embedding. 
% This ensures that the embedding process is well-distributed across the 
% entire expanded image and prevents any visible or statistical patterns 
% from arising, which could compromise the security and imperceptibility 
% of the steganographic method.

% Therefore, padding is necessary for balancing the bit spread 
% and maintaining the integrity of the embedding. It helps to achieve 
% a more robust and secure steganography technique.
% Convert the concatenated message to binary