clc;
%               2-channel RDH Image Steganography
%                     by: KHAN FARHAN RAFAT
%                        INVERSE Mod 5

stegoKey = 'C:\Users\user\Documents\2019-keyz.txt';
option = 0;

fileList = dir(fullfile('C:\Set12ix\inv5', '*.tif'));

for ifile = 1:length(fileList)
    orgImage = 'C:\Users\user\Downloads\Set12\';
    stegoImage=strcat(strcat(fileList(ifile).folder,"\"),fileList(ifile).name);
    [~, filename, ext] = fileparts(fileList(ifile).name);
    f=strcat(filename, ext);
    orgImage = fullfile(orgImage, [filename, '.png']);
    substringToRemove = '_KFR';
    orgImage = erase(orgImage, substringToRemove);
    
    info = imfinfo(stegoImage);
    numImages = numel(info);
    if numImages < 2
        error('The TIFF file does not contain enough pages.');
    end
    
    fileID = fopen(stegoKey, 'rb');
    if fileID == -1
        error('Unable to open the stegokey file: %s', stegokey);
    end
    byteData = fread(fileID, Inf, '*uint8');
    fclose(fileID);
    
    hash = uint8(System.Security.Cryptography.SHA256Managed().ComputeHash(byteData)); 
    hashBin = reshape(dec2bin(hash, 8).', 1, []);
    
    per = mod(sum(hash), 2) + 1;
    
    images = {imread(stegoImage, 'Index', 1), imread(stegoImage, 'Index', 2)};
    if per == 1
        % Assign the first image to originalImage and the second to cporiginalImage
        originalImage = images{1};
        cporiginalImage = images{2};
    else
        % Assign the first image to cporiginalImage and the second to originalImage
        originalImage = images{2};
        cporiginalImage = images{1};
    end
    oImageLength=numel(originalImage);
        byteData=hash;
        hash2 = [];
        num_ones=0;
         x1=1;
         x2=0;
         while(x1<3)
                bitstream='';
                num_ones=0;
                hash2='';
            while (1)
                hash1 = uint8(System.Security.Cryptography.SHA256Managed().ComputeHash(byteData));
                g=flip(hash1);
                hash2 = [hash2 hash1];
                byteData = g;
                bitstream = [bitstream reshape(dec2bin(hash2, 8).', 1, [])];
                num_ones = num_ones + sum(bitstream == '1');
                if num_ones >= oImageLength && numel(bitstream) >= oImageLength
                    break;
                end
            end
            if x1==1
                hp1=bitstream;
                byteData=g;
                x1=2;
            elseif x1==2
                hp2=bitstream;
                x1=3;
            else
                error("HASH Error.")
            end
         end
    
    rng(sum(hash));
    imageSize = oImageLength;
    onesPercentage = 0.60; % Percentage of '1's in the stegokey (85%)
    
    numOnes = round(imageSize * onesPercentage);
    numZeros = imageSize - numOnes;
    
    onesIndices = find(hp1 == '1');
    selectedIndices = randsample(onesIndices, min(numOnes, length(onesIndices)));
    selectedBits = hp1(selectedIndices);
    
    stegokey = repmat(' ', 1, imageSize);
    
    if ~isempty(selectedBits)
        randomPositions = randperm(imageSize, length(selectedBits));
        stegokey(randomPositions) = '1';
        numOnes = numOnes - length(selectedBits);
    end
    
    emptyPositions = find(stegokey == ' ');
    remainingBits = [ones(1, numOnes), zeros(1, numZeros)];
    remainingBits = remainingBits(randperm(length(remainingBits)));
    stegokey(emptyPositions) = char(remainingBits + '0');
    
    hp1 = char(stegokey);
    oImageLength = uint8(imread(orgImage));
    
    if isequal(oImageLength,  originalImage)
        % % imshow(originalImage);
        disp('The Cover and the Retrieved Image are Identical');
    else
        disp('The images are different');
    end
    
    %
    [rows, cols,~]=size(originalImage);
    % Initialize variables
    chp1 = 0;
    chp2 = 0;
    counter = 0;
    k=0;
    modf = rows * cols;
    extractedMessage = [];
    
    for i = 1:rows
        for j = 1:cols
            k=k+1;
            if hp1(k) == '1'
                counter = mod(counter, modf) + 1;
                
                yz = bitget(cporiginalImage(i, j), 1);
                xy = bitget(originalImage(i, j), 1);
                
                xr = bitxor(hp2(counter)-'0', yz);
                
                if xy == 1
                    xr = ~xr;
                end
                
                extractedMessage(counter) = xr;
            end
        end
    end
    
    numBits = length(extractedMessage);
    truncateLength = floor(numBits / 8) * 8;
    extractedMessageTruncated = extractedMessage(1:truncateLength);
    
    extractedMessageReshaped = reshape(extractedMessageTruncated, 8, []).';
    
    binaryCharArray = char(extractedMessageReshaped + '0');
    
    charArray = char(bin2dec(binaryCharArray));
    ul=str2double(strtrim(char(charArray(1:8)).')); 
    filename = strtrim(char(charArray(9:20)).');
    xorBitString=charArray(21:end).';    

    defaultPath = 'C:\Set12ix\inv5\';
    fullFilePath = fullfile(defaultPath, filename);
    fileID = fopen(fullFilePath, 'wb');
    if fileID == -1
        error('Failed to open file for writing.');
    end
    fwrite(fileID, xorBitString, 'uint8');
    fclose(fileID);
    tabulate_metrics(originalImage, cporiginalImage,f,'C:\Set12ix\inv5\stego_metrics.csv');
    % compare_perceptual_hashes(originalImage, cporiginalImage);
end

function tabulate_metrics(cover_img, stego_img, f, output_file)
    % Convert images to double precision for calculations
    cover = double(cover_img);
    stego = double(stego_img);

    % Image dimensions
    [rows, cols] = size(cover);
    N = rows * cols;  % Total number of pixels

    % Compute PSNR (Peak Signal-to-Noise Ratio)
    mse_value = sum((cover(:) - stego(:)).^2) / N;  % Mean Squared Error
    psnr_value = 10 * log10(255^2 / mse_value);  % PSNR formula

    % Compute RMSE (Root Mean Square Error)
    rmse_value = sqrt(mse_value);  % RMSE formula

    % Compute PCC (Pearson Correlation Coefficient)
    mean_cover = mean(cover(:));
    mean_stego = mean(stego(:));
    numerator = sum((cover(:) - mean_cover) .* (stego(:) - mean_stego));
    denominator = sqrt(sum((cover(:) - mean_cover).^2) * sum((stego(:) - mean_stego).^2));
    pcc_value = numerator / denominator;  % Pearson formula

    % Compute MAE (Mean Absolute Error)
    mae_value = sum(abs(cover(:) - stego(:))) / N;  % MAE formula

    % Compute SSIM (Structural Similarity Index)
    K1 = 0.01; K2 = 0.03; L = 255; % Constants
    C1 = (K1 * L)^2;
    C2 = (K2 * L)^2;

    mu_cover = mean(cover(:));  % Mean of cover image
    mu_stego = mean(stego(:));  % Mean of stego image
    sigma_cover = var(cover(:)); % Variance of cover
    sigma_stego = var(stego(:)); % Variance of stego
    sigma_cross = cov(cover(:), stego(:)); % Covariance
    sigma_cross = sigma_cross(1,2);

    ssim_value = ((2 * mu_cover * mu_stego + C1) * (2 * sigma_cross + C2)) / ...
                 ((mu_cover^2 + mu_stego^2 + C1) * (sigma_cover + sigma_stego + C2));

    % Compute Multi-Scale SSIM (MS-SSIM) - Approximate Version
    ms_ssim_value = ssim_value * (2 * sigma_cross / (sigma_cover + sigma_stego));  % Simplified MS-SSIM

    % Compute Entropy
    entropy_cover = compute_entropy(cover);
    entropy_stego = compute_entropy(stego);

    % Compute Bit Embedding Rate (BER)
    ber_value = sum(abs(cover(:) - stego(:))) / N;

    % Check if the file exists to determine whether to write the header
    write_header = ~isfile(output_file);

    % Open the file for appending results
    fid = fopen(output_file, 'a');

    % If it's the first time writing, print the header
    if write_header
        header = {'File Name', 'PSNR (dB)', 'RMSE', 'PCC', 'MAE', 'SSIM', 'MS-SSIM', 'EntropyC', 'EntropyS', 'BER'};
        fprintf(fid, '%s,', header{1:end-1});
        fprintf(fid, '%s\n', header{end});
        
        % Also display the header in the same format as the CSV file
        fprintf('%s,', header{1:end-1});
        fprintf('%s\n', header{end});
    end

    % Append the results for the current image to the file
    fprintf(fid, '%s,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n', ...
        f, psnr_value, rmse_value, pcc_value, mae_value, ...
        ssim_value, ms_ssim_value, entropy_cover, entropy_stego, ber_value);

    % Also display the results in the same format as the CSV file
    fprintf('%s,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n', ...
        f, psnr_value, rmse_value, pcc_value, mae_value, ...
        ssim_value, ms_ssim_value, entropy_cover, entropy_stego, ber_value);

    % Close the file
    fclose(fid);
end

% % function tabulate_metrics(cover_img, stego_img,f)
% %     % Convert images to double precision for calculations
% %     cover = double(cover_img);
% %     stego = double(stego_img);
% % 
% %     % Image dimensions
% %     [rows, cols] = size(cover);
% %     N = rows * cols;  % Total number of pixels
% % 
% %     % Compute PSNR (Peak Signal-to-Noise Ratio)
% %     mse_value = sum((cover(:) - stego(:)).^2) / N;  % Mean Squared Error
% %     psnr_value = 10 * log10(255^2 / mse_value);  % PSNR formula
% % 
% %     % Compute RMSE (Root Mean Square Error)
% %     rmse_value = sqrt(mse_value);  % RMSE formula
% % 
% %     % Compute PCC (Pearson Correlation Coefficient)
% %     mean_cover = mean(cover(:));
% %     mean_stego = mean(stego(:));
% %     numerator = sum((cover(:) - mean_cover) .* (stego(:) - mean_stego));
% %     denominator = sqrt(sum((cover(:) - mean_cover).^2) * sum((stego(:) - mean_stego).^2));
% %     pcc_value = numerator / denominator;  % Pearson formula
% % 
% %     % Compute MAE (Mean Absolute Error)
% %     mae_value = sum(abs(cover(:) - stego(:))) / N;  % MAE formula
% % 
% %     % Compute SSIM (Structural Similarity Index)
% %     K1 = 0.01; K2 = 0.03; L = 255; % Constants
% %     C1 = (K1 * L)^2;
% %     C2 = (K2 * L)^2;
% % 
% %     mu_cover = mean(cover(:));  % Mean of cover image
% %     mu_stego = mean(stego(:));  % Mean of stego image
% %     sigma_cover = var(cover(:)); % Variance of cover
% %     sigma_stego = var(stego(:)); % Variance of stego
% %     sigma_cross = cov(cover(:), stego(:)); % Covariance
% %     sigma_cross = sigma_cross(1,2);
% % 
% %     ssim_value = ((2 * mu_cover * mu_stego + C1) * (2 * sigma_cross + C2)) / ...
% %                  ((mu_cover^2 + mu_stego^2 + C1) * (sigma_cover + sigma_stego + C2));
% % 
% %     % Compute Multi-Scale SSIM (MS-SSIM) - Approximate Version
% %     ms_ssim_value = ssim_value * (2 * sigma_cross / (sigma_cover + sigma_stego));  % Simplified MS-SSIM
% % 
% %     % Compute Entropy
% %     entropy_cover = compute_entropy(cover);
% %     entropy_stego = compute_entropy(stego);
% % 
% %     % Compute Bit Embedding Rate (BER)
% %     ber_value = sum(abs(cover(:) - stego(:))) / N;
% % 
% %     % Display Results Row-wise
% %     fprintf('Metric                              Value\n');
% %     fprintf('-----------------------------------------\n');
% %     fprintf('File Name                          %s\n',f);
% %     fprintf('PSNR (dB)                          %.4f\n', psnr_value);
% %     fprintf('RMSE                               %.4f\n', rmse_value);
% %     fprintf('PCC                                %.4f\n', pcc_value);
% %     fprintf('MAE                                %.4f\n', mae_value);
% %     fprintf('SSIM                               %.4f\n', ssim_value);
% %     fprintf('MS-SSIM                            %.4f\n', ms_ssim_value);
% %     fprintf('Entropy Cover                      %.4f\n', entropy_cover);
% %     fprintf('Entropy Stego                      %.4f\n', entropy_stego);
% %     fprintf('BER                                %.4f\n', ber_value);
% % end

%% Compute Entropy Function
function entropy_val = compute_entropy(img)
    img = uint8(img);
    pixel_counts = imhist(img) / numel(img);  % Normalize histogram
    pixel_counts(pixel_counts == 0) = []; % Remove zero values to avoid log(0)
    entropy_val = -sum(pixel_counts .* log2(pixel_counts)); % Entropy formula
end

function compare_perceptual_hashes(cover_path, stego_path)
    % Read grayscale images
    cover = double(cover_path);
    stego = double(stego_path);

    % Compute perceptual hashes
    ahash_cover = average_hash(cover);
    ahash_stego = average_hash(stego);
    dhash_cover = difference_hash(cover);
    dhash_stego = difference_hash(stego);
    phash_cover = perceptual_hash(cover);
    phash_stego = perceptual_hash(stego);
    whash_cover = wavelet_hash(cover);
    whash_stego = wavelet_hash(stego);

    % Compute Hamming Distances
    ahash_diff = hamming_distance(ahash_cover, ahash_stego);
    dhash_diff = hamming_distance(dhash_cover, dhash_stego);
    phash_diff = hamming_distance(phash_cover, phash_stego);
    whash_diff = hamming_distance(whash_cover, whash_stego);

    % Classify hash difference
    ahash_category = classify_difference(ahash_diff);
    dhash_category = classify_difference(dhash_diff);
    phash_category = classify_difference(phash_diff);
    whash_category = classify_difference(whash_diff);

    % Tabulate results
    headers = {'Hash Type', 'Cover Hash', 'Stego Hash', 'Hamming Distance', 'Difference Category'};
    values = {
        'Average Hash (aHash)', ahash_cover, ahash_stego, ahash_diff, ahash_category;
        'Difference Hash (dHash)', dhash_cover, dhash_stego, dhash_diff, dhash_category;
        'Perceptual Hash (pHash)', phash_cover, phash_stego, phash_diff, phash_category;
        'Wavelet Hash (wHash)', whash_cover, whash_stego, whash_diff, whash_category;
    };

    % Display formatted table
    fprintf('\n%-25s %-64s %-64s %-20s %-20s\n', headers{:});
    fprintf('%s\n', repmat('-', 1, 200));
    for i = 1:size(values, 1)
        fprintf('%-25s %-64s %-64s %-20d %-20s\n', values{i, :});
    end
end

%% Compute Average Hash (aHash)
function hash = average_hash(img)
    img = imresize(img, [8, 8]); % Resize to 8x8
    avg_val = mean(img(:)); % Compute mean pixel value
    hash = binary_to_hex(img > avg_val);
end

%% Compute Difference Hash (dHash)
function hash = difference_hash(img)
    img = imresize(img, [8, 9]); % Resize to 8x9
    hash = binary_to_hex(img(:, 1:8) > img(:, 2:9)); % Column-wise differences
end

%% Compute Perceptual Hash (pHash)
function hash = perceptual_hash(img)
    img = imresize(img, [32, 32]); % Resize for DCT
    dct_matrix = dct2(img); % Compute Discrete Cosine Transform
    dct_low = dct_matrix(1:8, 1:8); % Extract top-left 8x8 DCT coefficients
    threshold = median(dct_low(:));  % Use median instead of mean
    hash = binary_to_hex(dct_low > threshold);
end

%% Compute Wavelet Hash (wHash)
function hash = wavelet_hash(img)
    img = imresize(img, [32, 32]); % Resize for wavelet transform
    [LL, ~, ~, ~] = dwt2(img, 'haar'); % Apply Haar wavelet transform
    threshold = median(LL(:));  % Use median instead of mean
    hash = binary_to_hex(LL > threshold);
end

%% Compute Hamming Distance
function dist = hamming_distance(hash1, hash2)
    bin1 = hex_to_bin(hash1);
    bin2 = hex_to_bin(hash2);

    % Ensure equal length before comparison
    min_len = min(length(bin1), length(bin2));
    bin1 = bin1(1:min_len);
    bin2 = bin2(1:min_len);

    dist = sum(bin1 ~= bin2); % Count differing bits
end

%% Convert Hex to Binary Without Toolbox
function bin_vector = hex_to_bin(hex_str)
    bin_str = '';
    for i = 1:length(hex_str)
        bin_str = [bin_str, dec2bin(hex2dec(hex_str(i)), 4)]; 
    end
    bin_vector = bin_str(:)' - '0'; % Convert to binary vector
end

%% Convert Binary Hash to Hex String
function hex_str = binary_to_hex(binary_hash)
    binary_vector = binary_hash(:)'; % Convert matrix to row vector
    binary_str = strrep(num2str(binary_vector), ' ', ''); % Remove spaces
    hex_str = dec2hex(bin2dec(reshape(binary_str, 4, []).')); % Convert to hex
    hex_str = reshape(hex_str', 1, []); % Convert matrix to row string
end

%% Classify Hash Differences
function category = classify_difference(diff)
    if diff == 0
        category = '0 (Identical)';
    elseif diff <= 2
        category = '1-2 (Minimal)';
    elseif diff <= 5
        category = '3-5 (Minor)';
    elseif diff <= 10
        category = '6-10 (Moderate)';
    else
        category = '>10 (Significant)';
    end
end
