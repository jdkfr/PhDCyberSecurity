% pngFile = 'C:\Set12e\1.png';
for xx=1:12
    pp='C:\Set12e\';
    pp=strcat(pp,strtrim(string(xx)));

    pngFile=strcat(pp,".png");
    pngData = imread(pngFile);
    clc;
    % Get the dimensions of the PNG image
    [rows, cols] = size(pngData);
    
    % Calculate the total number of pixels in the image
    numPixels = rows * cols;
    
    % A special script that MATLAB executes every time you restart
    rng("shuffle");
    
    % Generate random bits between 0 and 1
    randomBits = randi([0, 1], 1, 2 * numPixels);
    
    % Convert the PNG data to binary
    binaryData = dec2bin(pngData(:), 8);
    
    % Replace the least significant bit (LSB) with the generated random bits
    binaryData(:, end) = num2str(randomBits(1:numPixels).');
    binaryDataCopy = binaryData;
    binaryDataCopy(:, end) = num2str(randomBits(numPixels+1:end).');
    
    % Convert the modified binary data back to uint8
    modifiedData = uint8(bin2dec(binaryData));
    modifiedDataCopy = uint8(bin2dec(binaryDataCopy));
    
    % Reshape the modified data back to the original image size
    mi1 = reshape(modifiedData, rows, cols);
    mi2 = reshape(modifiedDataCopy, rows, cols);
    
    % Display the modified images
    subplot(3, 2, 1);
    imshow(mi1);
    title('Modified Cover Image 1');
    
    subplot(3, 2, 2);
    imshow(mi2);
    title('Modified Cover Image 2');
    
    % Read the "stegokey" file in binary format
    stegokeyFile = 'C:\Users\user\Desktop\PhD II\algonew.txt';
    fileID = fopen(stegokeyFile, 'rb');
    stegokeyData = fread(fileID, Inf, 'uint8');
    fclose(fileID);
    
    % Compute HASH
    sha256hasher = System.Security.Cryptography.SHA256Managed;
    hash1 = uint8(sha256hasher.ComputeHash(uint8(stegokeyData)));% stegokey1 256-bit
    
    % to permute the final cover copies
    per = mod(sum(hash1),6); % 1st hash
    
    hash2 = uint8(sha256hasher.ComputeHash(uint8(hash1)));
    stegokeyData1 = uint8(sha256hasher.ComputeHash(bitxor(uint8(hash2),hash1)));
    while length(hash2)* 8 <numPixels %stego-key
        hash2 = [hash2 uint8(sha256hasher.ComputeHash(uint8(hash2)))];
        % Convert the hash to binary format
        binaryHash1 = [binaryHash1 dec2bin(hash2,8)];
        binaryHash2 = reshape(binaryHash2.',1,[]);
    end
    hash2 = binaryHash(1:numPixels); % stegokey2 = pixelz
    x=sprintf("second %s - %d", hash2(1:25), length(hash2));
    disp(x);
    
    % Read the "message" file
    stegokeyFile = 'C:\Users\user\Desktop\gr8.txt';
    fileID = fopen(stegokeyFile, 'rb');
    message = fread(fileID, Inf, 'uint8');
    fclose(fileID);
    [~, name, ext] = fileparts(stegokeyFile);
    
    % XOR message and stegokey files
    message = sprintf('%8.8d%8.8s%4.4s%s', numel(message), name, ext, message);
    
    message=dec2bin(message, 8);
    message = reshape(message.', 1, []);
    
    hash3 = uint8(sha256hasher.ComputeHash(uint8(stegokeyData1)));
    while length(hash3)* 8 <length(message)
        stegokeyData1 = hash3;
        hash3 = [hash3 uint8(sha256hasher.ComputeHash(uint8(stegokeyData1)))];
    end
    disp(message)
    
    % Convert the hash to binary format
    xorHash = dec2bin(hash3,8);
    binaryHash = reshape(xorHash.',1,[]);
    hash3 = binaryHash(1:length(message)); % xor with message
    x=sprintf(" third %s", hash3(1:25));
    disp(x);
    
    % % % xorBitString = '';
    % % % for i = 1:length(message)
    % % %         xorBitString = strcat(xorBitString,bitxor(uint8(message(i)),uint8(hash3(i)))+'0');
    % % % end % holds, ready for embedding, encrypted message bits
    
    % Preallocate memory for xorBitString
    xorBitString = char(zeros(1, length(message)));
    
    % Convert message and hash3 to uint8 outside the loop
    message_uint8 = uint8(message);
    hash3_uint8 = uint8(hash3);
    
    % Perform vectorized bitxor operation
    xorResult = bitxor(message_uint8, hash3_uint8);
    
    % Convert the result to a string of '0's and '1's
    xorBitString = char('0' + xorResult);
    
    % holds, ready for embedding, encrypted message bits
    
    
    
    % Display the XOR result
    disp(strcat("   msg ",message));
    disp(strcat("   xor ",xorBitString));
    
    k = 1;
    lxorm = length(xorBitString);
    for i = 1:numPixels
        if hash2(k) == '1' % stego-key
            mi2(i) = bitset(mi2(i), 1, str2double(xorBitString(k)));
        else
            mi1(i) = bitset(mi1(i), 1, str2double(xorBitString(k)));
        end
        k=k+1;
        if k>lxorm
            break;
        end
    end
    if k<lxorm
        disp("Message exceeds Cover Image Length!")
        exit(1);
    end
    
    % Display the modified images
    % % % subplot(3, 2, 3);
    % % % imshow(mi1);
    % % % title('Stego Image 1');
    % % % 
    % % % subplot(3, 2, 4);
    % % % imshow(mi2);
    % % % title('Stego Image 2');
    
    % Extract the LSBs of each image
    f_lsb = bitget(pngData, 1);
    e_lsb = bitget(mi1, 1);
    d_lsb = bitget(mi2, 1);
    
    % XOR the LSBs of the three images
    result_lsb = bitxor(bitxor(f_lsb, e_lsb), d_lsb);
    
    % Place the result in the LSBs of the f image
    f_new = pngData;
    f_new = bitset(f_new, 1, result_lsb);
    % % % subplot(3, 2, 5);
    % % % imshow(f_new);
    
    title('Final Stego Image');
    if per==0
        merged=cat(3, f_new, mi1, mi2);%123
    elseif per==1
        merged=cat(3, f_new, mi2, mi1);%132
    elseif per==2
        merged=cat(3, mi1, f_new, mi2);%213
    elseif per==3
        merged=cat(3, mi1, mi2, f_new);%231
    elseif per==4
        merged=cat(3, mi2, f_new, mi1);%312
    elseif per==5
        merged=cat(3, mi2, mi1, f_new);%321
    end

    qq='C:\Set12x\';
    qq=strcat(qq,strtrim(string(xx)));
    qq=strcat(qq,".png");
    imwrite(merged,qq);
    % imwrite(merged,'C:\Set12x\08x.png');
end