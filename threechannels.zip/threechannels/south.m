pngFile = 'C:\Users\user\Downloads\kodak3s\kodim01_stego.png';
pngData = imread(pngFile);    
    % Get the dimensions of the PNG image
    [rows, cols, c] = size(pngData);

    % Calculate the total number of pixels in the image
    numPixels = rows * cols;

% w = waitforbuttonpress;% wait 
% =========================================================================
% Read the "stegokey" file in binary format
stegokeyFile = 'C:\Users\user\Desktop\PhD II\algonew.txt';
fileID = fopen(stegokeyFile, 'rb');
stegokeyData = fread(fileID, Inf, 'uint8');
fclose(fileID);

% Compute HASH
sha256hasher = System.Security.Cryptography.SHA256Managed;
hash1 = uint8(sha256hasher.ComputeHash(uint8(stegokeyData)));% stegokey1 256-bit

% to permute the final cover copies
per = mod(sum(hash1),6); % 1st hash
% =========================================================================
hash2 = uint8(sha256hasher.ComputeHash(uint8(hash1)));
stegokeyData1 = uint8(sha256hasher.ComputeHash(bitxor(uint8(hash2),hash1)));
while length(hash2)* 8 <numPixels %stego-key
    hash2 = [hash2 uint8(sha256hasher.ComputeHash(uint8(hash2)))];
end
% Convert the hash to binary format
binaryHash = dec2bin(hash2,8);
binaryHash = reshape(binaryHash.',1,[]);
hash2 = binaryHash(1:numPixels); % stegokey2 = pixelz
x=sprintf("second %s", hash2(1:25));
disp(x);
% =========================================================================
hash3 = uint8(sha256hasher.ComputeHash(uint8(stegokeyData1)));
while length(hash3)* 8 <numPixels % stego-key
    stegokeyData1 = hash3;
    hash3 = [hash3 uint8(sha256hasher.ComputeHash(uint8(stegokeyData1)))];
end
% Convert the hash to binary format
xorHash = dec2bin(hash3,8);
binaryHash = reshape(xorHash.',1,[]);
hash3 = binaryHash(1:numPixels); % xor with message
x=sprintf(" third %s", hash3(1:25));
disp(x);
% -------------------------------------------------------------------------

% f_lsb = pngData(:,:, 1);
% e_lsb = pngData(:,:, 2);
% d_lsb = pngData(:,:, 3);
% Split channels
% per=0;
if per==0
    f_lsb = pngData(:,:, 1);
    e_lsb = pngData(:,:, 2);
    d_lsb = pngData(:,:, 3);
elseif per==1
    f_lsb = pngData(:,:, 1);
    e_lsb = pngData(:,:, 3);
    d_lsb = pngData(:,:, 2);
elseif per==2
    f_lsb = pngData(:,:, 2);
    e_lsb = pngData(:,:, 1);
    d_lsb = pngData(:,:, 3);
elseif per==3
    f_lsb = pngData(:,:, 3);
    e_lsb = pngData(:,:, 1);
    d_lsb = pngData(:,:, 2);
elseif per==4
    f_lsb = pngData(:,:, 2);
    e_lsb = pngData(:,:, 3);
    d_lsb = pngData(:,:, 1);
elseif per==5
    f_lsb = pngData(:,:, 3);
    e_lsb = pngData(:,:, 2);
    d_lsb = pngData(:,:, 1);
end

% Extract the LSBs of each image
f = bitget(f_lsb, 1);
e = bitget(e_lsb, 1);
d = bitget(d_lsb, 1);

% XOR the LSBs of the three images
result_lsb = bitxor(bitxor(f, e), d);

% Place the result in the LSBs of the f image
f_new = f_lsb;
f_new = bitset(f_new, 1, result_lsb);

o_image=imread('C:\Users\user\Downloads\kodak3c\kodim01.png');

if f_new==o_image
    subplot(2, 2, 1);
    imshow(o_image);
    title('Original Image');

    subplot(2, 2, 2);
    imshow(f_new);
    title('Retrieved Image');

    disp('yes!')
else
    disp('Ooooopz!')
    return;
end



% -------------------------------------------------------------------------
k=1;
ns=0;
lxorm=160;
xorBitString = '';
for i=1:numPixels
    if hash2(k)=='1' % stego-key
        x=bitget(d_lsb(i),1);
        xorBitString = [xorBitString bitxor(uint8(hash3(k)),x)];
    else
        x=bitget(e_lsb(i),1);
        xorBitString = [xorBitString bitxor(uint8(hash3(k)),x)];
    end
    k=k+1;
    if k>lxorm
        ns=i+1;
        break;
    end
end

if k<lxorm || ns==0
    disp("Error while extracting information!")
    exit(1);
end
xorBitString=char(bin2dec(reshape(xorBitString,8,[]).').');
ul=str2double(xorBitString(1:8));
fx=xorBitString(9:20);
[rw, cl]=size(f_new);
xorBitString = '';
if (ns+ul*8)-1<=rw*cl
    for i=ns:(ns+ul*8)-1
        if hash2(k)=='1' % stego-key
            x=bitget(d_lsb(i),1);
            xorBitString = [xorBitString bitxor(uint8(hash3(k)),x)];
        else
            x=bitget(e_lsb(i),1);
            xorBitString = [xorBitString bitxor(uint8(hash3(k)),x)];
        end
        k=k+1;
    end
end

xorBitString=char(bin2dec(reshape(xorBitString,8,[]).').')
fx=strcat('C:\Set12x\',strtrim(fx));
fileID = fopen(fx, 'w');
fwrite(fileID,xorBitString);
fclose(fileID);
system(fx);
return;